"""
Selina Safety Evidence pipeline.

Turns a photo or short video clip into structured, privacy protected evidence
for the Safety Agent. This module is the OpenCV 5 core of the Selina entry
for the OpenCV AI Competition 2026, Agentic Vision path.

The pipeline output is meant to change what the Safety Agent does next
(raise priority, ask for a retake, prepare a clearer escalation), not just
describe the image. See evidence_to_action() at the bottom for that step.

Note on the OpenCV version: this was built and tested against the OpenCV
build available in this environment (4.13). The competition requires OpenCV
5. Before final submission, reinstall against the actual OpenCV 5 release
and rerun the test suite, the API used here (cv2.CascadeClassifier,
cv2.Laplacian, cv2.calcOpticalFlowFarneback) is stable across both.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

FACE_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"

# Thresholds, tuned to be conservative rather than clever. False negatives
# (missing a real problem) are worse than false positives here, since a
# human always reviews the result before anything is shared or escalated.
BLUR_VARIANCE_THRESHOLD = 100.0   # below this, the image is treated as too blurry
DARK_MEAN_THRESHOLD = 40.0        # below this, the image is treated as too dark
BRIGHT_MEAN_THRESHOLD = 220.0     # above this, treated as blown out
MOTION_FLAG_THRESHOLD = 1.5       # mean optical flow magnitude that counts as notable
# Calibrated against tests/make_sample_data.py: a calm clip with a 10 frame
# camera shake burst measures a mean magnitude around 2.0 to 2.5 across the
# whole clip. Recalibrate this against real device footage before relying
# on it for the actual demo, synthetic motion is a reasonable proxy, not a
# substitute for testing on a real phone clip.


@dataclass
class QualityReport:
    is_usable: bool
    blur_variance: float
    mean_brightness: float
    reason: Optional[str] = None


@dataclass
class FaceBlurResult:
    output_path: str
    faces_blurred: int


@dataclass
class MotionReport:
    flagged: bool
    mean_motion: float
    peak_frame_index: Optional[int] = None


@dataclass
class EvidenceResult:
    source_path: str
    quality: QualityReport
    face_blur: Optional[FaceBlurResult] = None
    motion: Optional[MotionReport] = None
    key_frame_path: Optional[str] = None
    notes: list = field(default_factory=list)


def check_quality(image: np.ndarray) -> QualityReport:
    """Flag images that are too blurry or too poorly exposed to be useful,
    so the person is asked to retake rather than silently keeping a bad
    submission in the record."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur_variance = cv2.Laplacian(gray, cv2.CV_64F).var()
    mean_brightness = float(np.mean(gray))

    if mean_brightness < DARK_MEAN_THRESHOLD:
        return QualityReport(False, blur_variance, mean_brightness, "too dark")
    if mean_brightness > BRIGHT_MEAN_THRESHOLD:
        return QualityReport(False, blur_variance, mean_brightness, "overexposed")
    if blur_variance < BLUR_VARIANCE_THRESHOLD:
        return QualityReport(False, blur_variance, mean_brightness, "too blurry")

    return QualityReport(True, blur_variance, mean_brightness, None)


def blur_faces(image: np.ndarray, output_path: str) -> FaceBlurResult:
    """Detect faces and blur them before anything leaves the pipeline, so
    bystanders and other third parties are not exposed. This runs on every
    submission, there is no option to skip it."""
    face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    output = image.copy()
    for (x, y, w, h) in faces:
        region = output[y:y + h, x:x + w]
        blurred = cv2.GaussianBlur(region, (51, 51), 30)
        output[y:y + h, x:x + w] = blurred

    cv2.imwrite(output_path, output)
    return FaceBlurResult(output_path, len(faces))


def analyze_motion(video_path: str) -> MotionReport:
    """Scan a short clip for sudden or repeated movement. This is a
    prioritization signal for human review, not a claim about what
    happened, and it is described that way anywhere it surfaces."""
    cap = cv2.VideoCapture(video_path)
    ok, prev = cap.read()
    if not ok:
        cap.release()
        return MotionReport(False, 0.0)

    prev_gray = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)
    magnitudes = []
    frame_index = 0
    peak_frame_index = 0
    peak_magnitude = 0.0

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame_index += 1
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        flow = cv2.calcOpticalFlowFarneback(prev_gray, gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        magnitude, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
        mean_mag = float(np.mean(magnitude))
        magnitudes.append(mean_mag)
        if mean_mag > peak_magnitude:
            peak_magnitude = mean_mag
            peak_frame_index = frame_index
        prev_gray = gray

    cap.release()

    if not magnitudes:
        return MotionReport(False, 0.0)

    mean_motion = float(np.mean(magnitudes))
    return MotionReport(
        flagged=mean_motion > MOTION_FLAG_THRESHOLD,
        mean_motion=mean_motion,
        peak_frame_index=peak_frame_index,
    )


def extract_key_frame(video_path: str, output_path: str, target_frame_index: Optional[int] = None) -> str:
    """Pull one clear, representative frame out of a clip, so the incident
    timeline stores a single usable image rather than a raw video nobody
    has time to review."""
    cap = cv2.VideoCapture(video_path)
    frame_index = 0
    best_frame = None
    best_score = -1.0

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        if target_frame_index is not None:
            if frame_index == target_frame_index:
                best_frame = frame
                break
        else:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            score = cv2.Laplacian(gray, cv2.CV_64F).var()
            if score > best_score:
                best_score = score
                best_frame = frame

        frame_index += 1

    cap.release()

    if best_frame is None:
        raise ValueError(f"Could not read any frames from {video_path}")

    cv2.imwrite(output_path, best_frame)
    return output_path


def process_image(image_path: str, output_dir: str) -> EvidenceResult:
    """Full pipeline for a single photo submission."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not read image at {image_path}")

    quality = check_quality(image)
    result = EvidenceResult(source_path=image_path, quality=quality)

    if not quality.is_usable:
        result.notes.append(f"Flagged for retake: {quality.reason}")
        return result

    blurred_path = str(Path(output_dir) / f"blurred_{Path(image_path).name}")
    result.face_blur = blur_faces(image, blurred_path)
    result.notes.append(f"{result.face_blur.faces_blurred} face(s) blurred before storage")

    return result


def process_video(video_path: str, output_dir: str) -> EvidenceResult:
    """Full pipeline for a short video submission: quality check on the key
    frame, motion analysis across the clip, key frame extraction, then face
    blurring on that frame before it is stored."""
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    motion = analyze_motion(video_path)
    key_frame_path = str(Path(output_dir) / f"keyframe_{Path(video_path).stem}.jpg")
    extract_key_frame(video_path, key_frame_path, target_frame_index=motion.peak_frame_index)

    key_frame_image = cv2.imread(key_frame_path)
    quality = check_quality(key_frame_image)

    result = EvidenceResult(
        source_path=video_path,
        quality=quality,
        motion=motion,
        key_frame_path=key_frame_path,
    )

    if motion.flagged:
        result.notes.append(f"Notable movement pattern detected, mean magnitude {motion.mean_motion:.2f}")

    if not quality.is_usable:
        result.notes.append(f"Key frame flagged for retake: {quality.reason}")
        return result

    blurred_path = str(Path(output_dir) / f"blurred_{Path(key_frame_path).name}")
    result.face_blur = blur_faces(key_frame_image, blurred_path)
    result.notes.append(f"{result.face_blur.faces_blurred} face(s) blurred before storage")

    return result


def evidence_to_action(result: EvidenceResult) -> dict:
    """This is the step that satisfies the Agentic Vision requirement: the
    vision result changes what happens next, it does not just describe the
    image. Returns the next action the Safety Agent should take."""
    if not result.quality.is_usable:
        return {
            "action": "request_retake",
            "reason": result.quality.reason,
        }

    if result.motion and result.motion.flagged:
        return {
            "action": "raise_priority_for_review",
            "reason": "movement pattern worth a closer look",
            "evidence_path": result.face_blur.output_path if result.face_blur else result.key_frame_path,
        }

    return {
        "action": "add_to_timeline",
        "reason": "usable evidence, no motion flag raised",
        "evidence_path": result.face_blur.output_path if result.face_blur else result.key_frame_path,
    }
